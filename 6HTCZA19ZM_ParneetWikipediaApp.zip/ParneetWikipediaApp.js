let searchInputEl = document.getElementById("searchInput");
let searchResultsEl = document.getElementById("searchResults")
let spinnerEl = document.getElementById("spinner");

function createAndAppendSearchResult(result) {
    let {
        title,
        link,
        description
    } = result;
    let resultItemEl = document.createElement("div");
    resultItemEl.classList.add("result-item");
    searchResultsEl.appendChild(resultItemEl);

    let titleEl = document.createElement("a");
    titleEl.href = link;
    titleEl.classList.add("result-title");
    titleEl.target = "_blank";
    titleEl.textContent = title;
    resultItemEl.appendChild(titleEl);

    let breakEl = document.createElement("br");
    resultItemEl.appendChild(breakEl);

    let urlEl = document.createElement("a");
    urlEl.href = link;
    urlEl.target = "_blank";
    urlEl.classList.add("result-url");
    urlEl.textContent = link;
    resultItemEl.appendChild(urlEl);

    let breakline = document.createElement("br");
    resultItemEl.appendChild(breakline);

    let descEl = document.createElement("p");
    descEl.classList.add("link-description");
    descEl.textContent = description;
    resultItemEl.appendChild(descEl);
}

function displayResults(search_results) {
    spinnerEl.classList.toggle("d-none");
    for (let result of search_results) {
        createAndAppendSearchResult(result);
    }
}

function searchWikipedia(event) {
    if (event.key === "Enter") {
        spinnerEl.classList.toggle("d-none");
        searchResultsEl.textContent = ""; // clears the previous result.
        let searchInput = searchInputEl.value;
        let url = "https://apis.ccbp.in/wiki-search?search=" + searchInput;
        let options = {
            method: "GET"
        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                let {
                    search_results
                } = jsonData;
                displayResults(search_results);
            })
    }
}


searchInputEl.addEventListener("keydown", searchWikipedia);